
export const cartData = [
    {
        id: 1,
        num: 5,
        addr:'Shanghai Sjtu',
        bought:true,
        state:'派送中'
    },
    {
        id: 2,
        num: 2,
        addr:'Jiangsu ',
        bought:true,
        state:'已到达'
    },
    {
        id: 3,
        num: 2,
        addr:'Shanghai Sjtu',
        bought:false,
        state:'None'
    },
    {
        id: 4,
        num: 2,
        addr:'Shanghai Sjtu',
        bought:true,
        state:'尚未发货'
    },
];
