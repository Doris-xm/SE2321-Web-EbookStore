export const booksData = [
    {
        id: 1,
        title: 'The Great Gatsby',
        author: 'F. Scott Fitzgerald',
        price: 9.99,
        cover: require('../asset/cover/book1.png')
    },
    {
        id: 2,
        title: 'To Kill a Mockingbird',
        author: 'Harper Lee',
        price: 8.99,
        cover:  require('../asset/cover/book2.jpg')
    },
    {
        id: 3,
        title: '1984',
        author: 'George Orwell',
        price: 7.99,
        cover:  require('../asset/cover/book1.png')
    },
    {
        id: 4,
        title: '1984',
        author: 'George Orwell',
        price: 7.99,
        cover:  require('../asset/cover/book1.png')
    },
    {
        id: 5,
        title: '1984',
        author: 'George Orwell',
        price: 7.99,
        cover:  require('../asset/cover/book1.png')
    },
    {
        id: 6,
        title: '1984',
        author: 'George Orwell',
        price: 7.99,
        cover:  require('../asset/cover/book1.png')
    },
];
