import React from "react";
import { useState } from 'react';
import { booksData } from '../data/book'; // 自定义图书数据
import {cartData} from "../data/cart";
import {Layout, InputNumber, Table, Tag, Checkbox, Button} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import '../css/View.css'
import {Link} from "react-router-dom";

// const [cartData, setCartData] = useState([]);
interface DataType {
    name: string;
    author: string;
    price: number;
    num: number;
    total: number;
    selected: boolean; // 新增加的选择框字段
}



export class Cart extends React.Component {
    state = { cartData };
    handleNumChange= (id: number, value: number) => {
        const updatedCartData = this.state.cartData.map((item) => {
            if (item.id === id) {
                return { ...item, num: value };
            } else {
                return item;
            }
         });
            // 更新购物车状态
            this.setState({ cartData: updatedCartData });
    }

    handleSelectChange= (id: number) =>  {
        const updatedCartData = this.state.cartData.map((item) => {
            if (item.id === id) {
                return { ...item, selected: !item.selected };
            } else {
                // 第二次点击
                return item;
            }
        });
        // 更新购物车状态
        this.setState({ cartData: updatedCartData });
    }
    render = () => {

        const columns: ColumnsType<DataType> = [
            {
                title: '',
                dataIndex: 'id',
                key: 'id',
                render: (id, record) => (
                    <Checkbox
                        checked={record.selected}// 根据 selected 字段确定当前复选框是否选中
                        onChange={() => this.handleSelectChange([record.id]) }
                       />
                ),
            },
            {
                title: '书名',
                dataIndex: 'title',
                key: 'title',
                render: (text) => <a>{text}</a>,
            },
            {
                title: '作者',
                dataIndex: 'author',
                key: 'author'
            },
            {
                title: '价格',
                dataIndex: 'price',
                key: 'price',
            },
            {
                title: '数量',
                dataIndex: 'num',
                key: 'num',
                render: (text, record) => (
                    <InputNumber
                        min={1}
                        defaultValue={text}
                        onChange={(value) => this.handleNumChange(record.id, value)}
                    />
                ),
            },
            {
                title: '总价',
                dataIndex: 'total',
                key: 'total',
            },
        ];
        // 初始化每个商品的 selected 字段

         // 把购物项与图书数据合并，生成最终的表格数据
        const combinedData = this.state.cartData.map(cartItem => {
            const bookItem = booksData.find(book => book.id === cartItem.id);
            return {
                id: cartItem.id,
                num: cartItem.num,
                title: bookItem.title,
                author: bookItem.author,
                price: bookItem.price,
                cover: bookItem.cover,
                total: bookItem.price * cartItem.num,
                selected: cartItem.selected || false, // 默认未选中
            };
        });
        return (
            <Layout className={'my-content'}>
                <h1 >My Cart</h1>
                <Checkbox.Group
                    // value={this.state.cartData.filter(item => item.selected).map(item => item.id)}
                    onChange={(checkedValue) => this.handleSelectChange(checkedValue)}>
                    <div className={'my-content'}>
                        <Table rowKey={record => record.id}
                            columns={columns} dataSource={combinedData} />
                    </div>

                </Checkbox.Group>
                <div>
                    <Button className="buttons"  >
                        <Link to="http://www.alipay.com/" target="_blank">付款</Link>
                    </Button>
                </div>

            </Layout>
        );
    };
};
export default Cart;




