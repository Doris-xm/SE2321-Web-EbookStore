package com.example.ebook_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
