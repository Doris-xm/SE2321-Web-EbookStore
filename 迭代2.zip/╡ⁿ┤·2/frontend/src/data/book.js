export const booksData = [
    {
        id: 1,
        title: 'The Great Gatsby',
        author: 'F. Scott Fitzgerald',
        price: 9.99,
        cover: 'https://s1.ax1x.com/2023/04/06/ppIWwC9.jpg'
    },
    {
        id: 2,
        title: 'To Kill a Mockingbird',
        author: 'Harper Lee',
        price: 8.99,
        cover:  'https://s1.ax1x.com/2023/04/06/ppIWgED.jpg'
    },
    {
        id: 3,
        title: '1984',
        author: 'George Orwell',
        price: 7.99,
        cover: 'https://s1.ax1x.com/2023/04/06/ppIfTzR.png'
    },
    {
        id: 4,
        title: '1985',
        author: 'George Orwell',
        price: 7.99,
        cover: 'https://s1.ax1x.com/2023/04/06/ppIfTzR.png'
    },
    {
        id: 5,
        title: '1986',
        author: 'George Orwell',
        price: 7.99,
        cover: 'https://s1.ax1x.com/2023/04/06/ppIfTzR.png'
    },
    {
        id: 6,
        title: '1987',
        author: 'George Orwell',
        price: 7.99,
        cover: 'https://s1.ax1x.com/2023/04/06/ppIfTzR.png'
    },
];
